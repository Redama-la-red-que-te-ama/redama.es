Telewave Antenna Pattern Files and Descriptions

42D 25		ANT42D 38.5-47 MHz Dipole 1-2.5 dBd 1/4 wave spacing
44D 25		ANT44D 41.5-48 MHz Dipole 1-2.5 dBd 1/4 wave spacing
150D 25		ANT150D 138-174 MHz Dipole 1-2.5 dBd 1/4 wave spacing
150D 37		ANT150D 138-174 MHz Dipole 1-2.5 dBd 3/8 wave spacing
150D 50		ANT150D 138-174 MHz Dipole 1-2.5 dBd 1/2 wave spacing
150D3 25	ANT150D3 138-174 MHz Dipoles 3-6 dBd 1/4 wave spacing
150D3 37	ANT150D3 138-174 MHz Dipoles 3-6 dBd 3/8 wave spacing
150D3 50	ANT150D3 138-174 MHz Dipoles 3-6 dBd 1/2 wave spacing
150D6-9 25	ANT150D6-9 138-174 MHz Dipoles 6-9 dBd 1/4 wave spacing
150D6-9 37	ANT150D6-9 138-174 MHz Dipoles 6-9 dBd 3/8 wave spacing
150D6-9 50	ANT150D6-9 138-174 MHz Dipoles 6-9 dBd 1/2 wave spacing
150D7-12 25	ANT150D7-12 138-174 MHz Dipoles 7-12 dBd 1/4 wave spacing
150D7-12 37	ANT150D7-12 138-174 MHz Dipoles 7-12 dBd 3/8 wave spacing
150D7-12 50	ANT150D7-12 138-174 MHz Dipoles 7-12 dBd 1/2 wave spacing
150F2		ANT150F2 148-174 MHz Fiberglass Collinear 2.5 dBd omni
150F6-3		ANT150F6-3 150-157 MHz Fiberglass Collinear 6 dBd omni
150F6-7		ANT150F6-7 167-172.5 MHz Fiberglass Collinear 6 dBd omni
150Y7		ANT150Y7-WR 148-174 MHz Yagi 5 dBd
150Y10H		ANT150Y10H 144-174 MHz Yagi 10 dBd
220D 25		ANT220D 216-252 MHz Dipoles 1-2.5 dBd 1/4 wave spacing
220D 37		ANT220D 216-252 MHz Dipoles 1-2.5 dBd 3/8 wave spacing
220D 50		ANT220D 216-252 MHz Dipoles 1-2.5 dBd 1/2 wave spacing
220D3 25	ANT220D3 216-252 MHz Dipoles 3-6 dBd 1/4 wave spacing
220D3 37	ANT220D3 216-252 MHz Dipoles 3-6 dBd 3/8 wave spacing
220D3 50	ANT220D3 216-252 MHz Dipoles 3-6 dBd 1/2 wave spacing
220D6-9 25	ANT220D6-9 216-252 MHz Dipoles 6-9 dBd 1/4 wave spacing
220D6-9 37	ANT220D6-9 216-252 MHz Dipoles 6-9 dBd 3/8 wave spacing
220D6-9 50	ANT220D6-9 216-252 MHz Dipoles 6-9 dBd 1/2 wave spacing
220F2		ANT220F2 195-260 MHz Fiberglass Collinear 2.5 dBd omni
220F6		ANT220F6 216-225 MHz Fiberglass Collinear 6 dBd omni
280S		ANT280S 118-3000 MHz Discone 0 dBd
450D 25		ANT450D 406-512 MHz Dipole 1-2.5 dBd 1/4 wave spacing
450D 37		ANT450D 406-512 MHz Dipole 1-2.5 dBd 3/8 wave spacing
450D 50		ANT450D 406-512 MHz Dipole 1-2.5 dBd 1/2 wave spacing
450D3 25	ANT450D3 406-512 MHz Dipoles 3-6 dBd 1/4 wave spacing
450D3 37	ANT450D3 406-512 MHz Dipoles 3-6 dBd 3/8 wave spacing
450D3 50	ANT450D3 406-512 MHz Dipoles 3-6 dBd 1/2 wave spacing
450D6-9 25	ANT450D6-9 406-512 MHz Dipoles 6-9 dBd 1/4 wave spacing
450D6-9 37	ANT450D6-9 406-512 MHz Dipoles 6-9 dBd 3/8 wave spacing
450D6-9 50	ANT450D6-9 406-512 MHz Dipoles 6-9 dBd 1/2 wave spacing
450F2		ANT450F2 420-480 MHz Fiberglass Collinear 2.5 dBd omni
450F6		ANT450F6 445-480 MHz Fiberglass Collinear 6 dBd omni
450F10		ANT450F10 430-475 MHz Fiberglass Collinear 10 dBd omni
450Y5		ANT450Y5-WR 420-470 MHz Yagi 5 dBd
450Y5H		ANT450Y5-WRH 420-470 MHz Yagi 5 dBd
450Y7		ANT450Y7-WR 450-470 MHz Yagi 7 dBd
450Y10		ANT450Y10-WR 450-470 MHz Yagi 10 dBd
475Y5		ANT475Y5-WR 450-512 MHz Yagi 5 dBd
734-960F2	ANT734-960F2 734-960 MHz Fiberglass Collinear 2.5 dBd omni
740Y8		ANT740Y8-WR 698-787 MHz Yagi 8 dBd
750Y5		ANT750Y5-WR 734-806 MHz Yagi 5 dBd
750Y5H		ANT750Y5-WRH 734-806 MHz Yagi 5 dBd
770F2		ANT770F2 734-806 MHz Fiberglass Collinear 2.5 dBd omni
770F6		ANT770F6 746-806 MHz Fiberglass Collinear 6 dBd omni
825F6		ANT825F6 745-860 MHz Fiberglass Collinear 6 dBd omni
830F6		ANT830F6 745-885 MHz Fiberglass Collinear 6 dBd omni
830Y10		ANT830Y10-WR 800-870 MHz Yagi 10 dBd
850F2		ANT850F2 806-896 MHz Fiberglass Collinear 2.5 dBd omni
850F6		ANT850F6 806-896 MHz Fiberglass Collinear 6 dBd omni
850F10		ANT850F10 806-896 MHz Fiberglass Collinear 10 dBd omni
850Y10		ANT850Y10-WR 824-896 MHz Yagi 10 dBd
2400Y12		ANT2400Y12-WR 2400-2500 MHz Yagi 12 dBd